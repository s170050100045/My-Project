package com.ecomm.dao;

import java.util.List;

import com.ecomm.model.Deal;

public interface DealDAO 
{
	public boolean addDeal(Deal deal);
	public boolean deleteDeal(Deal deal);
	public boolean updateDeal(Deal deal);
	public Deal getDeal(int dealId);
	public List<Deal> listDeal();
}

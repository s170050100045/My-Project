package com.ecomm.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ecomm.model.Deal;

@Repository("dealDAO")
@Transactional
public class DealDAOImpl implements DealDAO
{
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public boolean addDeal(Deal deal) 
	{
		try
		{
			sessionFactory.getCurrentSession().save(deal);
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}

	@Override
	public boolean deleteDeal(Deal deal) {
		try
		{
			sessionFactory.getCurrentSession().delete(deal);
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}

	@Override
	public boolean updateDeal(Deal deal) {
		try
		{
			sessionFactory.getCurrentSession().update(deal);
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}

	@Override
	public Deal getDeal(int dealId) 
	{
		Session session=sessionFactory.openSession();
		Deal deal=(Deal)session.get(Deal.class,dealId);
		session.close();
		return deal;
	}

	@Override
	public List<Deal> listDeal() 
	{
		Session session=sessionFactory.openSession();
		List<Deal> listDeal=session.createQuery("from Deal").list();
		session.close();
		return listDeal;
	}
	
	
}

package com.shop.QuestBackEnd;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ecomm.dao.DealDAO;
import com.ecomm.model.Deal;
public class DealDAOTestCase {
	
static DealDAO dealDAO;
	
	@BeforeClass
	public static void initialize()
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.ecomm");
		context.refresh();
		dealDAO=(DealDAO)context.getBean("dealDAO");
	}
	
	@Test
	public void addDealTest()
	{
		Deal deal=new Deal();
		deal.setDealName("IndependencDaySale");
		deal.setDiscount(10);
		deal.setStartDate(new java.util.Date());
		
		assertTrue("Problem in Inserting Deal",dealDAO.addDeal(deal));
	}



}

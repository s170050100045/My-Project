package com.shop.QuestBackEnd;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ecomm.dao.ProductDAO;
import com.ecomm.model.Product;


public class ProductDAOTestCase {
static ProductDAO productDAO;
	
	@BeforeClass
	public static void initialize()
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		
		context.scan("com.ecomm");
		
		context.refresh();
		
		productDAO=(ProductDAO)context.getBean("productDAO");
	}
	
	@Ignore
	@Test
	public void addProductTest()
	{
		
		Product product=new Product();
		product.setProductName("Samsung j7");
		product.setProductDesc("3G Mobile with Good Camera and Memory");
		product.setCategoryId(1);
		product.setDealId(2);
		product.setPrice(9000);
		
		assertTrue("Problem in Inserting Product",productDAO.addProduct(product));
	}
	@Ignore
	@Test
	public void updateProductTest()
	{
		Product product=productDAO.getProduct(2);
		
		product.setProductName("Samsung J5");
		product.setPrice(8500);
		
		assertTrue("Problem in Updating the Product",productDAO.updateProduct(product));
	}
	@Ignore
	@Test
	public void deleteProductTest()
	{
		Product product=productDAO.getProduct(2);
		
		assertTrue("Problem in deleting the Product",productDAO.deleteProduct(product));
	}
	
	@Test
	public void listProductsTest()
	{
		List<Product> listProducts=productDAO.listProducts();
		
		assertTrue("No Products Found",listProducts.size()>0);
		
		for(Product product:listProducts)
		{
			System.out.print(product.getProductId()+":::::");
			System.out.print(product.getProductName()+"::::");
			System.out.print(product.getProductName()+"::::");
			System.out.println(product.getPrice()+"::::");
		}
	}


}

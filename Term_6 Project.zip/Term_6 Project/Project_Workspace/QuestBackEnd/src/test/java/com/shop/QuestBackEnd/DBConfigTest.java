package com.shop.QuestBackEnd;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
public class DBConfigTest {
	public static void main(String arg[])
	{
	AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
	
	context.scan("com.ecomm");
		
	context.refresh();
	}

}
